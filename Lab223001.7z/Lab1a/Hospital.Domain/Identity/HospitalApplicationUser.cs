﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital.Domain.Identity
{
    public class HospitalApplicationUser: IdentityUser
    {
        //името, презимето и датумот на раѓање на корисникот.

        public string? Name { get; set; }
        public string? Surname { get; set; }
        public DateTime BitrthDate { get; set; }

    }
}
