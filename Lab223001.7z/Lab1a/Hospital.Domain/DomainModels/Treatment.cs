﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital.Domain.DomainModels
{
    public class Treatment
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime DateAdministered { get; set; }
        public bool FollowUpRequired { get; set; }
        public Guid PatientId { get; set; }
        public Patient? Patient { get; set; }

    }
}
