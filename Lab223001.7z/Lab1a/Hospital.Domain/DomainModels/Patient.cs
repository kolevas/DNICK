﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital.Domain.DomainModels
{
    public class Patient
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? Surname { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        [Required]
        public DateTime AdmissionDate { get; set; }
        public virtual ICollection<PatientDepartment> PatientDepartments { get; set; }= new List<PatientDepartment>();

        public virtual ICollection<Treatment> Treatments { get; set; } = new List<Treatment>();

    }
}
