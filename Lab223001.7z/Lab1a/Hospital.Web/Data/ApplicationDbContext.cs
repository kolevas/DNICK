﻿using Hospital.Domain.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Hospital.Domain.DomainModels;

namespace Hospital.Web.Data
{
    public class ApplicationDbContext : IdentityDbContext<HospitalApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Hospital.Domain.DomainModels.Department> Department { get; set; } = default!;
        public DbSet<Hospital.Domain.DomainModels.Patient> Patient { get; set; } = default!;
        public DbSet<Hospital.Domain.DomainModels.Treatment> Treatment { get; set; } = default!;
        public DbSet<Hospital.Domain.DomainModels.PatientDepartment> PatientDepartment { get; set; } = default!;
    }
}
